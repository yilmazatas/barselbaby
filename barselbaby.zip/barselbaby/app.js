// Initialize Firebase
var firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "babyforum-1d6fa.firebaseapp.com",
  projectId: "babyforum-1d6fa",
  storageBucket: "babyforum-1d6fa.appspot.com",
  messagingSenderId: "751097491874",
  appId: "1:751097491874:web:525f2c0c3b7624db0342fb",
  measurementId: "G-QPPB00WYNB"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

document.addEventListener('DOMContentLoaded', (event) => {
  let slideIndex = 0;
  showSlides();

  function showSlides() {
    let slides = document.getElementsByClassName("mySlides");
    if (slides.length === 0) {
      console.error("No slides found.");
      return;
    }
    for (let i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) { slideIndex = 1 }    
    slides[slideIndex - 1].style.display = "block";  
    setTimeout(showSlides, 3000);
  }

  if (window.location.pathname.endsWith("forum.html")) {
    loadPosts();
  }
});

function register() {
  const email = document.getElementById("registerEmail").value;
  const password = document.getElementById("registerPassword").value;

  firebase.auth().createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
      window.location.href = "auth.html";
    })
    .catch((error) => {
      console.error("Error registering user: ", error.message);
    });
}

function login() {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      window.location.href = "forum.html";
    })
    .catch((error) => {
      console.error("Error logging in user: ", error.message);
    });
}

function createPost() {
  const title = document.getElementById("title").value;
  const content = document.getElementById("content").value;
  const user = firebase.auth().currentUser;

  if (!user) {
    document.getElementById('alert').classList.remove('hidden');
    return;
  }

  db.collection("posts").add({
    title: title,
    content: content,
    author: user.email,
    timestamp: firebase.firestore.FieldValue.serverTimestamp()
  })
  .then((docRef) => {
    window.location.href = "forum.html";
  })
  .catch((error) => {
    console.error("Error adding post: ", error);
  });
}

function loadPosts() {
  const postsContainer = document.getElementById("posts-container");

  db.collection("posts").orderBy("timestamp", "desc").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
      const post = doc.data();
      const postElement = document.createElement("div");
      postElement.classList.add("bg-white", "p-4", "rounded", "shadow", "mb-4");
      postElement.innerHTML = `
        <h3 class="text-xl font-bold">${post.title}</h3>
        <p class="text-sm text-gray-600">by ${post.author} on ${post.timestamp.toDate().toLocaleString()}</p>
        <p>${post.content}</p>
      `;
      postsContainer.appendChild(postElement);
    });
  })
  .catch((error) => {
    console.error("Error getting posts: ", error);
  });
}
